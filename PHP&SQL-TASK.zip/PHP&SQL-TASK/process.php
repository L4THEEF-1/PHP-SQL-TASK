<?php
$host = 'localhost';
$dbname = 'reviews_db';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Process Submission</title>
    <style>
        @font-face {
            font-family: 'Poppins'; src: url(Poppins.ttf);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to top, rgba(0, 40, 72, 1), rgba(16, 62, 98, 1), rgba(30, 88, 128, 1), rgba(159, 227, 238, 1));
            color: whitesmoke;
            max-width: 600px;
            overflow: hidden;
            margin: 0 auto;
            padding: 20px;
            height: 100vh;
        }
        .message {
            padding: 20px;
            border-radius: 23px;
            font-size: 1.2rem;
        }
        .success {
            background-color: rgba(212, 237, 218, 0.6);
            font-family: 'Poppins';
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: rgba(248, 215, 218, 0.6);
            color: #721c24;
            border: 1px solid #f5c6cb;
            box-shadow: 0 0 20px 1px rgba(167, 208, 234, 0.2);
        }
        a {
            text-decoration: none;
            color: #007bff;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $review = htmlspecialchars($_POST['review']);

    if (!empty($name) && !empty($email) && !empty($review)) {
        try {
            $stmt = $conn->prepare("INSERT INTO reviews (name, email, review) VALUES (:name, :email, :review)");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':review', $review);
            $stmt->execute();
            echo "<div class='message success'>Thank you for your review!<br><a href='form.php'>Submit another review</a></div>";
        } catch (PDOException $e) {
            echo "<div class='message error'>Error: " . $e->getMessage() . "<br><a href='form.php'>Go back to the form</a></div>";
        }
    } else {
        echo "<div class='message error'>All fields are required!<br><a href='form.php'>Go back to the form</a></div>";
    }
}
?>

</body>
</html>

<?php
ob_end_flush();
?>
